GUARDIAN SURVIVAL KIT

This archive contains the essential tools, files, and information to replicate, share, or build upon Guardian Protocol — a decentralized system for survivor-centered protection, transparency, and ethical defense.

Use it. Modify it. Share it. Make it unstoppable.
